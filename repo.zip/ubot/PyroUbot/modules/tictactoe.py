from PyroUbot import *

__MODULE__ = "ᴛɪᴄᴛᴀᴄᴛᴏᴇ"
__HELP__ = """
<blockquote>Bantuan Untuk Tictactoe

perintah : <code>{0}tictactoe</code>
   untuk memunculkan game tictactoe</blockquote>
"""
